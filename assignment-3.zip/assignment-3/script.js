document.addEventListener('DOMContentLoaded', () => {
    
    // --- Task 1: Greet User Functionality ---
    const nameInput = document.getElementById('name-input');
    const greetButton = document.getElementById('greet-button');
    const greetingHeader = document.getElementById('greeting-header');

    greetButton.addEventListener('click', () => {
        // Get the value from the input field and remove whitespace
        const userName = nameInput.value.trim();

        if (userName) {
            // DOM Manipulation: Change the header text content
            greetingHeader.textContent = `Hello, ${userName}`;
        } else {
            // Optional: If the field is empty, revert or prompt
            greetingHeader.textContent = `Hello! Please enter your name.`;
        }
    });


    // --- Task 2: Change Box Background Color Functionality ---
    const colorBoxes = document.querySelectorAll('.box');

    colorBoxes.forEach(box => {
        box.addEventListener('click', () => {
            // 1. Get the target color from the custom 'data-color' attribute
            const targetColor = box.getAttribute('data-color');
            
            // 2. Map the text color to a specific hex code for consistency
            let colorCode;
            let textColor = 'white'; // Default text color for dark backgrounds
            
            switch (targetColor.toLowerCase()) {
                case 'red':
                    colorCode = '#e74c3c'; // Flat UI Red
                    break;
                case 'blue':
                    colorCode = '#3498db'; // Flat UI Blue
                    break;
                case 'green':
                    colorCode = '#2ecc71'; // Flat UI Green
                    break;
                case 'yellow':
                    colorCode = '#f1c40f'; // Flat UI Yellow
                    textColor = '#333'; // Use dark text for better contrast on yellow
                    break;
                default:
                    colorCode = '#ecf0f1'; // Fallback
            }

            // 3. DOM Manipulation: Apply the background color and text color
            box.style.backgroundColor = colorCode;
            box.style.color = textColor;
            box.style.borderColor = 'transparent'; // Remove the initial border
        });
    });
});