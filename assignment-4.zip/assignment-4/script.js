$(document).ready(function() {
    // Selectors for key elements
    const $form = $('#validationForm');
    const $messageBox = $('#message-box');
    const $passwordInput = $('#password');
    const $togglePasswordButtons = $('.toggle-password');

    // --- 1. Modular Validation Functions ---

    /**
     * Clears all existing error messages from the form and the main message box.
     */
    function clearMessages() {
        $('.error-text').text('');
        $messageBox.hide().removeClass('error success').text('');
    }

    /**
     * Displays a main message in the message box (red for error, green for success).
     * @param {string} message - The text content of the message.
     * @param {string} type - 'error' or 'success'.
     */
    function displayMessage(message, type) {
        $messageBox.removeClass('error success').addClass(type).text(message).show();
    }

    /**
     * Validates if a field is empty.
     * @param {string} value - The input value.
     * @param {string} fieldName - The name of the field for the error message.
     * @returns {boolean} True if valid (not empty), False otherwise.
     */
    function validateRequired(value, fieldName) {
        if (value.trim() === '') {
            $(`#${fieldName}-error`).text(`${fieldName} is required.`);
            return false;
        }
        return true;
    }

    /**
     * Validates email format using a regex pattern.
     * @param {string} email - The email input value.
     * @returns {boolean} True if the format is valid.
     */
    function validateEmail(email) {
        // Standard email regex pattern: user@domain.tld
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            $('#email-error').text('Invalid email format (e.g., user@example.com).');
            return false;
        }
        return true;
    }

    /**
     * Validates phone number to be exactly 10 digits.
     * @param {string} phone - The phone input value.
     * @returns {boolean} True if the length is exactly 10.
     */
    function validatePhone(phone) {
        const phoneDigits = phone.replace(/\D/g, ''); // Remove non-digits
        if (phoneDigits.length !== 10) {
            $('#phone-error').text('Phone number must be exactly 10 digits.');
            return false;
        }
        return true;
    }

    /**
     * Validates password strength using a regex pattern.
     * Requirements: Min 8 chars, 1 uppercase, 1 lowercase, 1 number.
     * @param {string} password - The password input value.
     * @returns {boolean} True if the password is strong.
     */
    function validatePassword(password) {
        // Regex: at least 8 characters, one uppercase, one lowercase, one number.
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
        if (!passwordRegex.test(password)) {
            $('#password-error').text('Password must be 8+ chars, with upper/lower case and a number.');
            return false;
        }
        return true;
    }

    // --- 2. Event Handlers ---

    // Toggle Password Visibility
    $togglePasswordButtons.on('click', function() {
        // Get the target input element ID
        const targetId = $(this).data('target');
        const $targetInput = $(`#${targetId}`);
        const currentType = $targetInput.attr('type');

        // Toggle the input type between 'password' and 'text'
        if (currentType === 'password') {
            $targetInput.attr('type', 'text');
            $(this).find('.eye-icon').text('🔒'); // Change icon to locked/closed
        } else {
            $targetInput.attr('type', 'password');
            $(this).find('.eye-icon').text('👁️'); // Change icon back to open/visible
        }
    });

    // Main Form Submission Handler
    $form.on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission
        
        clearMessages(); // Clear previous messages

        // Get values from form inputs
        const name = $('#name').val();
        const email = $('#email').val();
        const phone = $('#phone').val();
        const password = $passwordInput.val();

        let isValid = true; // Assume valid until a check fails

        // Check Required Fields first (using short-circuit evaluation)
        isValid = validateRequired(name, 'name') && isValid;
        isValid = validateRequired(email, 'email') && isValid;
        isValid = validateRequired(phone, 'phone') && isValid;
        isValid = validateRequired(password, 'password') && isValid;
        
        // If required fields are valid, proceed to format validation
        if (isValid) {
            // Check Format Validation
            isValid = validateEmail(email) && isValid;
            isValid = validatePhone(phone) && isValid;
            isValid = validatePassword(password) && isValid;
        }

        // --- Final Outcome ---
        if (isValid) {
            // Success: Display success message
            displayMessage('Registration successful! Data sent to server (form prevented submission).', 'success');
            // Optional: Clear form fields
            $form[0].reset();
        } else {
            // Error: Display generic error message
            displayMessage('Please correct the errors marked in red and try again.', 'error');
        }
    });
});